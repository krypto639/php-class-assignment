<?php
$dataForSite = parse_ini_file( "../operation/localization.ini", true);
//$activeSite = "hindi";
$activeSite = "gameSite";
?>
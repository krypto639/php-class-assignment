<?php 
if($_SERVER["REQUEST_METHOD"] == "POST"){
    //echo "<script>alert('The post form has been submitted')</script>";
    if( strlen($_POST["postTitle"])>=3 && strlen($_POST["postTitle"])<=40 ){
        $postTitle=true;
    }else{
        $postTitle=false;
    }

    if( strlen($_POST["postText"])>=3 && strlen($_POST["postText"])<=250 ){
        $postContent=true;
    }else{
        $postContent=false;
    }

    if($postTitle==true && $postContent==true){
        //echo "<script>alert('title and content are within the correct parameters')</script>";
        $newPostTitle=$_POST["postTitle"];
        $newPostContent=$_POST["postText"];

        if(isset($_POST["updatePost-btn"]) ){
            $postEditingID=$_POST["postID"]; 
            $update = "UPDATE post SET postTitle='$newPostTitle', postContent='$newPostContent'
            WHERE postID=$postEditingID";
            $db->query($update);
            header( 'Location: ../pages/postPg.php' );

        }elseif( isset($_POST["createPost-btn"]) ){
        $uID=$_SESSION['user_ID'];
        $createPost = "INSERT INTO post (uID, postTitle, postContent) VALUES
        ($uID, '$newPostTitle',
        '$newPostContent');";
        $db->query($createPost);
        }
    
    }else{
        echo "<script>alert('The post form has been submitted but does not contatin correct details')</script>";
    }

}



?>

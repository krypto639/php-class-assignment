<?php
include '../validation/test-input.php';
$dbEmail='';
$password='';
$name='';
$errorMessage='';

if($_SERVER["REQUEST_METHOD"] == "POST"){//1
    global $dbEmail;

    $email = test_input($_POST['email'] );
    ////echo "<script>console.log('before filter validation email is $email ')</sript>";
    /*if( !isset($_POST['email']) ){//2
        $dbEmail='BAD';
        echo "<script>console.log('no email is provided')</script>";
    }else*/
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) ) {//2
        $dbEmail='BAD';
        //echo "<script>console.log('bad email of $email which is not a valid email $dbEmail')</script>";
    }elseif( filter_var($email, FILTER_VALIDATE_EMAIL) && isset($_POST['email']) ){//2
    $sql = "SELECT COUNT(uEmail) AS emailMatch FROM user WHERE uEmail='$email';";
    $emailChecker = $db->query($sql);
    $row=$emailChecker->fetch();
    $matchingEmail = $row['emailMatch'];
        if( $matchingEmail > 0 ){//3
            $dbEmail=true;
            //echo "<script>console.log('$matchingEmail match for $email and email is true and valid, accountEmail is $dbEmail')</script>";
        }else{//3
            $dbEmail=false;
            //echo "<script>console.log('$matchingEmail matches for $email in db, accountEmail is $dbEmail ')</script>";
        }
    }else{
        $dbEmail='BAD';
        //echo "<script>console.log('bad $email which is invalid, accountEmail is $dbEmail')</script>";
    }
}

//log in form
    if(isset($_POST['l-formSubmit'])){
        global $dbEmail, $password;
        $email = test_input( $_POST['email'] );
        $l_passwordEntered = test_input( $_POST['l-password'] );
        //echo "<script>console.log('email inputted is $email and password is $l_passwordEntered')</script>";

        if( isset($_POST['l-password']) && strlen($_POST['l-password'])>=8 && $dbEmail===true && isset($_POST['email'])){
            $email = test_input( $_POST['email'] );
            $l_passwordEntered = test_input( $_POST['l-password'] );
            
            $sql = "SELECT * FROM user WHERE uEmail='$email' LIMIT 1";
            $passwordChecker = $db->query($sql);
            $row=$passwordChecker->fetch();
            $passwordDB=$row['uPassword'];
            //echo "<script>console.log('database password for this email is $passwordDB')</script>";
            if( password_verify( $l_passwordEntered, $passwordDB )){
                //$row['uPassword']==$_POST['l-password'];
                $passwordEntered=$_POST['l-password'];
                //echo "<script>console.log('database password for this email is $passwordDB and inputed password is $passwordEntered')</script>";
                $password=true;
            }else{
                $password='BAD';
                //echo "<script>console.log('inputed password is $l_passwordEntered is $password and does not match db account')</script>";
            }
        }else{
            $password='BAD';
            //echo "<script>console.log('inputed password is $l_passwordEntered is $password not valid to short')</script>";
        }


        //validaing all inputs to confirm log in
        //echo "<script>console.log('inputed password is $password and email is $dbEmail')</script>";
        if($password===true && $dbEmail===true){
            //echo "<script>alert('a login form has been completed with all the correct details')</script>";
            $sql = "SELECT * FROM user WHERE uEmail='$email' LIMIT 1";
            $accountDetails = $db->query($sql);
            $row=$accountDetails->fetch();


            //session_start();
            $_SESSION['login_user'] = $row['uName'];
            $_SESSION['user_ID'] = $row['uID'];
            $_SESSION['user_Type'] = $row['uTypeID'];
            header('Location:../pages/postPg.php');

        }elseif($dbEmail===true && $password!==true){
            //echo "<script>alert('This is not the correct password')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['wrong_password_error'];
        }elseif($dbEmail===false){
            //echo "<script>alert('There is no account with this email')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['no_user_error'];
        }elseif($dbEmail=='BAD'||$password=='BAD'){
            //echo "<script>alert('Please fill out all the fields')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['incomplete_error'];
        }

    }

//registration form submitted
if(isset($_POST['regSubmit-btn'])){
    global $dbEmail, $password,$name,$errorMessage;
    $r_passwordEntered = test_input( $_POST['r-password'] );
    $r_nameEntered = test_input( $_POST['r-name'] );
    
    if(strlen($_POST['r-password'])>=8 && $_POST['r-password']==$_POST['r-passVerify'] ){
        $password=true;
        //echo "<script>console.log('passwords match and correct length')</script>";
        }elseif( $_POST['r-password']!==$_POST['r-passVerify'] ){
            $password='Do not match';
            //echo "<script>console.log('passwords do not match')</script>";
        }elseif( strlen($_POST['r-password'])< 8 && strlen($_POST['r-password'])> 0  && $_POST['r-password']==$_POST['r-passVerify']){
            $password='To short';
            //echo "<script>console.log('password are too small')</script>";
        }else{
            $password='BAD';
            //echo "<script>console.log('password empty')</script>";
        }
    
    if(strlen($r_nameEntered)>=3 && strlen($r_nameEntered)<=32  ){
        $name=true;
        //echo "<script>console.log('name is the correct size')</script>";
        }else{
            $name=false;
            //echo "<script>console.log('name is to large or small')</script>";
        }
    
   
    if($password===true && $dbEmail===false && $name===true){
        //echo "<script>alert('a ref form has been completed with all the correct details')</script>";
        $uPassword=test_input( $_POST['r-password'] );
        $uPassword = password_hash($uPassword, PASSWORD_DEFAULT);
        $uName=test_input( $_POST['r-name']);
        $uEmail= test_input( $_POST['email'] );
        $createUser = "INSERT INTO user ( uName, uPassword, uEmail) VALUES
        ('$uName','$uPassword','$uEmail' );";
        $db->query($createUser);

        $sql = "SELECT uID FROM user WHERE uEmail='$email' LIMIT 1";
        $passwordChecker = $db->query($sql);
        $row=$passwordChecker->fetch();


        //session_start();
        $_SESSION['login_user'] = $uName;
        $_SESSION['user_ID'] = $row['uID'];
        $_SESSION['user_Type'] = $row['uTypeID'];

        header('Location:../pages/postPg.php');

        }elseif($dbEmail===true && $password===true && $name===true){
            //echo "<script>alert('There is already an account with this email')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['user_already_exists_error'];

        }elseif($dbEmail===false && $password!==true && $name===true){
            if($password=='Do not match'){
            //echo "<script>alert('Your passwords do not match')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['passwords_match_error'];
            
            }elseif($password=='To short'){
            //echo "<script>alert('Your passwords are too short')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['passwords_length_error'];  
            }

        }elseif($dbEmail=='BAD' ||$password=='BAD' ||$name==false){
            //echo "<script>alert('Please fill out all the fields')</script>";
            $errorMessage=$dataForSite[$activeSite.'-logIn']['incomplete_error'];
        }
}
    
?>
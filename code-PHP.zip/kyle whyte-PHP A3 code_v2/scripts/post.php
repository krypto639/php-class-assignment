<script>
function viewComments($id) {
        var x = document.getElementById("commentDisplay_"+$id);
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }

    function likeBtnToggle($id) {
        var element = document.getElementById("likeBtn_"+$id);
        element.classList.toggle("activeBtn");
    }

    function saveBtnToggle($id) {
        var element = document.getElementById("saveBtn_"+$id);
        element.classList.toggle("activeBtn");
    }

    function commentBtnToggle($id) {
        var element = document.getElementById("commentBtn_"+$id);
        element.classList.toggle("activeBtn");
        var x = document.getElementById("commentInputBox_1");
        if (x.style.display === "none") {
            x.style.display = "block";
            x.style.height = "auto";
        } else {
            x.style.display = "none";
            x.style.height= 0;
        }
    }
    
    </script>



<script>
function showPasswordInput($id1, $id2){
    var p1= document.getElementById($id1)
    var pConfirm= document.getElementById($id2);
    if($id2=='r-passwordVerify'){
        if(p1.type=='password'){
            p1.type='text';
            pConfirm.type='text';
        }else{
            p1.type='password';
            pConfirm.type='password';
        }
    }else{
        if(p1.type=='password'){
            p1.type='text';
        }else{
            p1.type='password';
        }
    }
}

function showPasswordMatch(){
//use an oninput to trigger function and dipslay input change when match
var p1= document.getElementById('r-password');
var pConfirm= document.getElementById('r-passwordVerify');
if(p1.value===pConfirm.value && p1.value.length!==0){
    document.getElementById('r-formError').innerHTML="passwords match";
}else{
    document.getElementById('r-formError').innerHTML="";
}
}

function inputChange($formError){
    if($formError==='r-formError'){
    document.getElementById('r-formError').innerHTML="";
}else if($formError==='l-formError'){
    document.getElementById('l-formError').innerHTML="";
}
}
</script>
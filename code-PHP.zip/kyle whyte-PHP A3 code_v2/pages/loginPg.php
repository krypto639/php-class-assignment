<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
$activePage='LogIn';
include '../operation/db.php';
include '../validation/loginValidation.php'; 
include '../templates/navigationMenu.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">
    <link rel="icon" href="..\images\hindi\siteIcon.png">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['log_in'] ); ?></title>
</head>

<body id="logInPage">
    <div id="logInBox">
        <h1>
            <?php  echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['log_in'] );  ?>
        </h1>
        <form autocomplete="off" id="logInForm" name="logInForm" action="loginPg.php" disabled="disabled" method="POST">
            <label for="l-uEmail">
                <?php  echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['email'] );  ?>
            </label>
            <input type="text" id="l-uEmail" name="email" placeholder="email@gmail.com" oninput="inputChange('l-formError')"
                value="<?php if(isset($_POST['email'])){echo $_POST['email']; }; ?>">
            <br>
            <label for="l-pass">
                <?php  echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['password'] );  ?>
            </label>
            <input type="password" id="l-pass" name="l-password" oninput="inputChange('l-formError')"
                placeholder="<?php  echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['password_placeholder'] );  ?>"
                value="<?php if(isset($_POST['l-password'])){echo $_POST['l-password']; }; ?>">
            <br>
            <label for="passwordVisible-btn">
                <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['show_password'] ); ?>
            </label>
            <input type="checkbox" id="passwordVisible-btn" onchange="showPasswordInput('l-pass')">
            <br>
            <a href="register.php">
                <?php  echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['reg'] );  ?>
            </a>
            <br>
            <p class="error" id="l-formError"><?php if(isset($errorMessage)){ echo $errorMessage; } ?></p>
            <button name="l-formSubmit" class="form-submit" type="submit">
                <?php  echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['log_in'] );  ?>
            </button>
        </form>

    </div>

</body>
<?php include '..\scripts\loginAndReg.php'; ?>

</html>
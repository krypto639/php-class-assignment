<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
include '../operation/db.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo htmlspecialchars( $dataForSite[$activeSite]['home_title'] ); ?></title>
</head>

<body class="backgroundImage" style="background-image: <?php echo htmlspecialchars( $dataForSite[$activeSite]['home_image_background'] ); ?>;">

<?php include '../templates/navigationMenu.php'; ?>

        <div class="homepage_textDisplay">
            <h1><?php echo htmlspecialchars( $dataForSite[$activeSite]['home_title'] ); ?></h1>
            <h3><?php echo htmlspecialchars( $dataForSite[$activeSite]['home_secondary_greeting'] ); ?></h3>
        </div>
</body>

</html>
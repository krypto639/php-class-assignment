<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
include '../operation/db.php';
include '../validation/post.php';


$activePage='Account';
$uName = $_SESSION['login_user'];
$sql = "SELECT u.uName, u.uProfileImage,
(p.pLikes+c.cLikes) AS totalLikes,
	(SELECT COUNT(*) FROM Post p INNER JOIN User u ON p.uID=u.uID WHERE u.uName = '$uName') AS totalPosts,
	(SELECT COUNT(*) FROM Comment c INNER JOIN User u ON c.uID=u.uID WHERE u.uName = '$uName') AS totalComments,
	(SELECT COUNT(*) FROM savedPosts sp INNER JOIN User u ON sp.uID=u.uID WHERE u.uName = '$uName') AS totalSaves
FROM User u
INNER JOIN Post p ON u.uID=p.uID
INNER JOIN Comment c ON u.uID=c.uID
WHERE u.uName = '$uName';";
$accountInteractions = $db->query($sql);
$row=$accountInteractions->fetch();
//while ( $row=$accountInteractions->fetch() ){

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['account'] ); ?></title>
</head>
<body id="accountPg">
<?php include '../templates/navigationMenu.php'; ?>




<?php
if($row["uProfileImage"]!==NULL){
    $userProfileImage = $row["uProfileImage"];
    $imgPath = $dataForSite[$activeSite]['images_path'];
    $totalImagePath = $imgPath.$userProfileImage;

    ?>
    <div class='profileIcon'>
        <img src="<?php echo $totalImagePath; ?>" height="40px" width="40px" background-color="gray">
    </div>
<?php
}else{
    echo "<div class='profileIcon'>";
    include '..\images\svg\face-24px.svg';
    echo "</div>";
}?>
<h1 id="account-uName"><?php echo  $uName; ?></h1>
<div id="accountStat-container">
<div class="stat-box">
<p><?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['post_link'] ); ?></p>
    <h1><?php echo  $row['totalPosts']; ?></h1>
</div>
<div class="stat-box">
<p><?php echo htmlspecialchars( $dataForSite[$activeSite.'-post']['comment'] ); ?></p>
    <h1><?php echo  $row['totalComments']; ?></h1>
   
</div>
<div class="stat-box">
<p><?php echo htmlspecialchars( $dataForSite[$activeSite.'-post']['saved'] ); ?></p>
    <h1><?php echo  $row['totalSaves']; ?></h1>
   
</div>
</div>
<?php
//}

 ?>

</body>
</html>
<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
include '../operation/db.php';
$activePage='View Post';

$postID=$_GET['postID'];
$sql = "SELECT * FROM post p INNER JOIN user u WHERE p.postID=$postID";
$postRetriever = $db->query($sql);
$row=$postRetriever->fetch();

$sql2 = "SELECT COUNT(postID) AS 'commentTotal' FROM comment WHERE postID=$row[postID]";
    $commentCounter = $db->query($sql2);
    $count=$commentCounter->fetch();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo $row['postTitle']; ?></title>
</head>
<body>
<?php include '../templates/navigationMenu.php'; ?>
<div id="postViewbox">
<?php 

/*if( isset($_SESSION['user_ID']) ){
include '../templates/userPostCreate.php';
}*/
//$row = mysqli_fetch_array($result)

//while ($row=$postRetriever->fetch()){

    /*$sql2 = "SELECT COUNT(postID) AS 'commentTotal' FROM comment WHERE postID=$postID";
    $commentCounter = $db->query($sql2);
    $count=$commentCounter->fetch();*/

    
        include '..\templates\postDisplay.php';
        ?>
        
<?php
    //}
 ?>
 </div>
</body>
    <?php include '../scripts/post.php'; ?>
</html>
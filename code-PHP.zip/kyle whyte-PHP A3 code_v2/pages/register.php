<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
$activePage='register';
include '../operation/db.php';
include '../validation/loginValidation.php'; 
include '../templates/navigationMenu.php'; 

//VALIDATION
if($_SERVER["REQUEST_METHOD"] == "POST"){
   
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['register'] ); ?></title>
</head>

<body id="logInPage">
    <div id="logInBox">
    <h1>
        <?php  echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['register'] );  ?>
        </h1>
        <form id="RegisterForm" name="reg-form" action="register.php" method="POST">
            <!--Name-->
            <label for="r-name">
                <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['name'] ); ?>
            </label>
            <input type="text" name="r-name" id="r-name" size="32" oninput="inputChange('r-formError')"
            placeholder="<?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['name_placeholder'] );?>"
            value="<?php if(isset($_POST['r-name'])){echo $_POST['r-name']; }; ?>"><br>

            <!--Email-->
            <label for="r-email">
                <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['email'] ); ?>
            </label>
            <input type="text" name="email" id="r-email" placeholder="name@gmail.com" oninput="inputChange('r-formError')"
            value="<?php if(isset($_POST['email'])){echo $_POST['email']; }; ?>"><br>

            <!--Password-->
            <label for="r-password">
                <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['password'] ); ?>
            </label>
            <input type="password" name="r-password" size="24" id="r-password" oninput="showPasswordMatch()" 
            placeholder="<?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['password_placeholder'] );?>"
            value="<?php if(isset($_POST['r-password'])){echo $_POST['r-password']; }; ?>"><br>

                     <!--Verify Password-->
            <label for="r-passwordVerify">
                <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['verify_password'] ); ?>
            </label>
           <input type="password" id="r-passwordVerify" name="r-passVerify" size="24" oninput="showPasswordMatch()" 
           placeholder="<?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['v_password_placeholder'] );?>"
           value="<?php if(isset($_POST['r-passVerify'])){echo $_POST['r-passVerify']; }; ?>">
           <br>
                    <label for="passwordVisible-btn">
                    <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['show_password'] ); ?>
                    </label>
                    <input type="checkbox" id="passwordVisible-btn" onchange="showPasswordInput('r-password','r-passwordVerify')">
                    <br>
            <a href="loginPg.php">
            <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['log_swap'] ); ?>
            </a>
            <br>
            <p class="error" id="r-formError"><?php if(isset($errorMessage)){ echo $errorMessage; } ?></p>
            <button name="regSubmit-btn" class="form-submit" type="submit">
            <?php echo htmlspecialchars( $dataForSite[$activeSite.'-logIn']['register'] ); ?>
            </button>
        </form>
    </div>
    <?php include '..\scripts\loginAndReg.php'; ?>
</body>

</html>
<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
include '../operation/db.php';
include '../validation/post.php';
$activePage='Post';


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['post_link'] ); ?></title>
</head>
<body>
<?php include '../templates/navigationMenu.php'; ?>
<div class="centerColumn">
<?php 
if( isset($_GET['display']) &&  $_GET['display']=='newest'){
    $sql = "SELECT * FROM post p INNER JOIN user u ON u.uID=p.uID ORDER BY p.pDatetime DESC;";
    //echo "<a href='postPg.php?display=oldest'>oldest</a>";
    //SELECT * FROM post ORDER BY pDatetime DESC
}elseif( isset($_GET['display']) && $_GET['display']=='oldest'){
    $sql = "SELECT * FROM post p INNER JOIN user u ON u.uID=p.uID ORDER BY p.pDatetime ASC;";
    //echo "<a href='postPg.php?display=newest'>newest</a>";
}elseif( isset($_GET['display']) && $_GET['display']=='title'){
    $sql = "SELECT postTitle, postID, uID FROM post ORDER BY pDatetime DESC";
    //echo "<a href='postPg.php?display=newest'>newest</a>";
}else{
    $sql = "SELECT * FROM post p INNER JOIN user u ON u.uID=p.uID ORDER BY p.postID DESC;";
    //echo "<a href='postPg.php?display=newest'>newest</a>";
}
?>
<div id="changePostDisplay">
<a 
<?php if( isset($_GET['display']) && $_GET['display']=='title'){echo "class='activeFilter'";}?>
 href='postPg.php?display=title'><?php echo $dataForSite[$activeSite.'-post']['view_posts_by_title']; ?></a>
<br>
<a 
<?php if( isset($_GET['display']) && $_GET['display']=='oldest'){echo "class='activeFilter'";}?>
href='postPg.php?display=oldest'><?php echo $dataForSite[$activeSite.'-post']['oldest']; ?></a>
<br>
<a
<?php if( isset($_GET['display']) && $_GET['display']=='newest'){echo "class='activeFilter'";}?>
 href='postPg.php?display=newest'><?php echo $dataForSite[$activeSite.'-post']['newest']; ?></a>
</div>

<div id="allPostsDisplay">
<?php

if( isset($_SESSION['user_ID']) ){
include '../templates/userPostCreate.php';
}
//$sql = "SELECT * FROM post p INNER JOIN user u ON u.uID=p.uID";
$postRetriever = $db->query($sql);
$row=$postRetriever->fetch();
//$row = mysqli_fetch_array($result)

while ($row=$postRetriever->fetch()){
    $sql2 = "SELECT COUNT(postID) AS 'commentTotal' FROM comment WHERE postID=$row[postID]";
    $commentCounter = $db->query($sql2);
    $count=$commentCounter->fetch();

    if( !isset($_GET['display']) || $_GET['display']!=='title' ){
        include '../templates/postDisplay.php';

    }elseif( isset($_GET['display']) && $_GET['display']=='title' ){
        ?>
        <div class="titleDisplayOnly-post">
            <h2><?php echo $row['postTitle'];?></h2>
            <?php if(isset($_SESSION['user_ID']) && $row['uID']==$_SESSION['user_ID']){
                include '..\templates\userPostOptions.php';
            }
            ?>
            <a href="../pages/viewPost.php?postID=<?php echo $row['postID']; ?>">
            <?php echo $dataForSite[$activeSite.'-post']['view_post']; ?>
            </a>
        </div>
        <?php
    }
} 
 ?>
 </div>
</div>
</body>
    <?php include '../scripts/post.php'; ?>
</html>
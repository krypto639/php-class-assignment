<?php 
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
include '../operation/db.php';
include '../validation/post.php';


$activePage='Edit';
$postID = $_GET['postID'];
$sql = "SELECT * FROM post WHERE postID=$postID;";
$postRetriever = $db->query($sql);
//$row=$postRetriever->fetch();
while ( $row=$postRetriever->fetch() ){

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Yeon+Sung&display=swap" rel="stylesheet">
    <?php include '../styling/stylingAll.php'; ?>
    <title><?php echo htmlspecialchars( $dataForSite[$activeSite.'-post']['edit'] ); ?></title>
</head>
<body class="flexBody">
<?php include '../templates/navigationMenu.php'; ?>

<div id="editPostContent" class="editPost">
    <form action="editPost.php?postID=<?php echo $postID; ?>" method="POST" name="editPost">
                <input type="text" name="postID" value="<?php echo $postID; ?>" style="display:none;">
                <textarea id="" class="new-postTitleInput" name="postTitle" placeholder="
                <?php echo $dataForSite[$activeSite.'-post']['title_placeholder']; ?>"
                 rows="2" size="40">
                <?php echo $row["postTitle"]; ?>
                </textarea>

                <textarea rows="10" name="postText" size="250" placeholder="
                <?php echo $dataForSite[$activeSite.'-post']['content_placeholder']; ?>
                "><?php echo $row["postContent"]; ?></textarea>
    <input type="submit" name="updatePost-btn" id="updatePost-btn" value="<?php echo $dataForSite[$activeSite.'-post']['save_changes']; ?>">
    </form>
</div>
<?php 
}
/*$sql = "SELECT * FROM post p INNER JOIN user u ON u.uID=p.uID";
$postRetriever = $db->query($sql);
$row=$postRetriever->fetch();
//$row = mysqli_fetch_array($result)
while ($row=$postRetriever->fetch()){
    $sql2 = "SELECT COUNT(postID) AS 'commentTotal' FROM comment WHERE postID=$row[postID]";
    $commentCounter = $db->query($sql2);
    $count=$commentCounter->fetch();

    include '../templates/postDisplay.php';
} */
 ?>

</body>
</html>
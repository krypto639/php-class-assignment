<?php
session_start();
    unset( $_SESSION['login_user'] );
    unset( $_SESSION['user_ID'] );
    unset( $_SESSION['user_Type'] );
session_destroy();
   header("Location: ../pages/postPg.php");
?>
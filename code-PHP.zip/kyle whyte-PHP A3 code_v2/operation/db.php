<?php
session_start();
require 'functionsSQL.php';

$servername="localhost";
$dbUser="root";
$dbPass = htmlspecialchars( $dataForSite[$activeSite]['db_password'] );
$dbName = htmlspecialchars( $dataForSite[$activeSite]['db_name'] );


$db = new MySQL($servername, $dbUser, $dbPass, $dbName);
$db->createDatabase();
$db->selectDatabase();

//-------------------------
//unset($_SESSION['gameDBStarter']);
//unset($_SESSION['hindiDBStarter']);
include 'populateDb.php';
/*if( 
    !isset($_SESSION['gameDBStarter']) 
    && $dataForSite[$activeSite]['db_name']=='minotaur_game' ){
    include 'populateDb.php';

    $_SESSION['gameDBStarter']=true;
}elseif( !isset($_SESSION['hindiDBStarter']) && $dataForSite[$activeSite]['db_name']=='learn_hindi'){
    include 'populateDb.php';

    $_SESSION['hindiDBStarter']=true;
}*/

?>
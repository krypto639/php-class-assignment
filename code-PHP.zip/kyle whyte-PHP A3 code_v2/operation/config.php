<?php

    //$ini_array=parse_ini_file('localization.ini',true);
    $ini_array = parse_ini_file( "localization.ini", true);
    //print_r(parse_ini_file("try.ini", true));
    $preferredLocale="gameSite";
    $GLOBALS['locale']=[
        "localeData"=> $ini_array[$preferredLocale],
        "localeNav"=>$ini_array[$preferredLocale."-navContent"],
        "localeStyling"=>$ini_array[$preferredLocale."-styling"],
        "localePost"=>$ini_array[$preferredLocale."-post"], 
        "localeLogIN"=>$ini_array[$preferredLocale."-logIn"]   
    ];
    ?>
<?php
require '../operation/config.php'; 
require '../activeLocalization/siteInEffect.php';
include '../operation/db.php';

$postID=$_GET['postID'];
$deletePost = "DELETE FROM post WHERE postID=$postID;";
$db->query($deletePost);

header('Location: ../pages/postPg.php');
?>
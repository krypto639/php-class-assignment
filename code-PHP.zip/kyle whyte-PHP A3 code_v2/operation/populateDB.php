<?php
//userType
$create = "CREATE TABLE if not exists userType (
    uTypeID integer not null AUTO_INCREMENT,
    uType varchar(16) NOT NULL, 
    primary key(uTypeID) );";
$db->query($create);



//Status
$create = "CREATE TABLE if not exists Status (
    statusID int not null AUTO_INCREMENT, 
    statusType varchar(20) NOT NULL,
    primary key(statusID) );";
$db->query($create);

//User
$create = "CREATE TABLE if not exists User (
	uID int not null AUTO_INCREMENT,
	uTypeID int DEFAULT 1,
	uName varchar(32) NOT NULL,
	uPassword varchar(70) NOT NULL,
	uEmail varchar(64) NOT NULL,
	uRegDatetime datetime DEFAULT CURRENT_TIMESTAMP,  /*GETDATE(),*/
	uProfileImage varchar(64),
	uStatusID int DEFAULT 1,
	primary key (uID),
	foreign key (uTypeID) REFERENCES userType (uTypeID),
	foreign key (uStatusID) REFERENCES Status (statusID) );";
$db->query($create);

//Post
$create = "CREATE TABLE if not exists Post (
	postID int not null AUTO_INCREMENT,
	uID int,
	postTitle varchar(90) NOT NULL,
	postContent TEXT NOT NULL,
	pDatetime datetime DEFAULT CURRENT_TIMESTAMP,
	pStatusID int DEFAULT 1,
	pLikes int DEFAULT 0,
	primary key (postID),
	foreign key (uID) REFERENCES User (uID),
	foreign key (pStatusID) REFERENCES Status (statusID) );";
$db->query($create);

//SavedPost
$create = "CREATE TABLE if not exists savedPosts (
    postID int NOT NULL,
    uID int NOT NULL,
    primary key (postID, uID),
    foreign key (uID) REFERENCES User (uID),
    foreign key (postID) REFERENCES Post (postID) );";
$db->query($create);

//Comment
$create = "CREATE TABLE if not exists Comment (
    postID int NOT NULL,
    uID int NOT NULL,
    commentID int NOT NULL AUTO_INCREMENT,
    cDatetime datetime DEFAULT CURRENT_TIMESTAMP,
    cContent TEXT NOT NULL,
    cLikes int DEFAULT 0,
    cStatusID int DEFAULT 1,
    primary key (commentID, postID, uID),
    foreign key (postID) REFERENCES Post (postId),
    foreign key (cStatusID) REFERENCES Status (statusID),
    foreign key (uID) REFERENCES User (uID) );
";
$db->query($create);

/*//Reports
$create = "CREATE TABLE if not exists Reports (
    rDatetime datetime DEFAULT CURRENT_TIMESTAMP,
    uID int NOT NULL,
    postID int DEFAULT NULL,
    cID int DEFAULT NULL,
    primary key (rDatetime, uID, postID, cID),
    foreign key (uID) REFERENCES User (uID),
    foreign key (postID) REFERENCES Post (postID),
    foreign key (cID) REFERENCES Comment (commentID)
    );
";
$db->query($create);*/

//check empty script before inserting duplicates
$sql = "SELECT COUNT(uType) AS 'totalUserTypes' FROM userType";
$tableRows = $db->query($sql);
$row=$tableRows->fetch();
//echo "<script>alert(".$row['totalUserTypes'].");</script>";
if($row['totalUserTypes']<=0){
    //if the sql turns back a result do not insert
    //if gameSite
    if($dataForSite[$activeSite]['db_name']=='minotaur_game'){
        $insert = "INSERT INTO usertype (uType) VALUES ('user'), ('admin'); ";
        $db->query($insert);
    
        $insert = "INSERT INTO status (statusType) VALUES 
                ('Public'), 
                ('Draft'),
                ('Reported'),
                ('True Report'),
                ('False Report'),
                ('Restricted Access'),
                ('View Only'),
                ('Blocked');";
        $db->query($insert);
        
        //user hashed passwords
        $hashedPassword_ben ='$2y$10$uviArtFCuMEaSBPc83/uNeqxHN5iwC7spH.d5k/MUJ.nxSezLhe.S' ;
        $hashedPassword_sam ='$2y$10$ekdw0n25JvZ.hfyFls0iZO.jeIwKlSZgOd1ETUwySy7NMKpEAmK1.' ;
        $hashedPassword_alex ='$2y$10$I/41fGNDkurygrB3YpjkEOtlYi467wrXMky1spwWv6cK83zbKez0m' ;
        $hashedPassword_chloe ='$2y$10$FpQzElzDPvq5monFfAc36OW/3x48Op7gLvNSlb0ohs4sTjD6Pv4qS' ;
        $hashedPassword_damian ='$2y$10$V9sl0bfgTHDNjpI/ItYkz.BBJ6rSEKKg16KyB.f3FkvWiwV6uuvT6' ;

        $insert = "
                INSERT INTO user (uTypeID, uName, uPassword, uEmail, uStatusID) VALUES 
            (1,'Ben Ferguson', '$hashedPassword_ben', 'benferg@gmail.com',1),
            (1,'Samantha Adam', '$hashedPassword_sam', 'sAdams@gmail.com',1),
            (2,'Alex Cross', '$hashedPassword_alex', 'alexcross@gmail.com',1),
            (1,'Chloe Evans', '$hashedPassword_chloe', 'chloe.evans@gmail.com',1),
            (1,'Damian Skywalker', '$hashedPassword_damian', 'damien.s@gmail.com',3);";
            $db->query($insert);
    
        $insert = "
            INSERT INTO post (uID, postTitle, postContent, pStatusID, pLikes) VALUES
            ('1', 'Glitch level 7',
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Quam id leo in vitae. Nec feugiat in fermentum posuere urna nec tincidunt
            praesent semper. Proin nibh nisl condimentum id. Tempus quam pellentesque 
            nec nam aliquam sem et. Sociis natoque penatibus et magnis. A condimentum vitae sapien pellentesque habitant
            morbi tristique senectus. Rhoncus urna neque viverra justo nec ultrices. Metus dictum at tempor commodo 
            ullamcorper a lacus. Ut faucibus pulvinar elementum integer.',
            1, 2),
            ('4', 'Can someone help me understand how you complete lv 12?',
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Quam id leo in vitae. Nec feugiat in fermentum posuere urna nec tincidunt
            praesent semper. Proin nibh nisl condimentum id. Tempus quam pellentesque 
            nec nam aliquam sem et. Sociis natoque penatibus et magnis. A condimentum vitae sapien pellentesque habitant
            morbi tristique senectus. Rhoncus urna neque viverra justo nec ultrices. Metus dictum at tempor commodo 
            ullamcorper a lacus. Ut faucibus pulvinar elementum integer.',
            1, 3),
            ('1', 'Can we get new enemies after level 15',
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Quam id leo in vitae. Nec feugiat in fermentum posuere urna nec tincidunt
            praesent semper. Proin nibh nisl condimentum id. Tempus quam pellentesque 
            nec nam aliquam sem et. Sociis natoque penatibus et magnis. A condimentum vitae sapien pellentesque habitant
            morbi tristique senectus. Rhoncus urna neque viverra justo nec ultrices. Metus dictum at tempor commodo 
            ullamcorper a lacus. Ut faucibus pulvinar elementum integer.',
            1, 0),
            ('2', 'Where do I get the key for the silver door in lv 8?',
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Quam id leo in vitae. Nec feugiat in fermentum posuere urna nec tincidunt
            praesent semper. Proin nibh nisl condimentum id. Tempus quam pellentesque 
            nec nam aliquam sem et. Sociis natoque penatibus et magnis. A condimentum vitae sapien pellentesque habitant
            morbi tristique senectus. Rhoncus urna neque viverra justo nec ultrices. Metus dictum at tempor commodo 
            ullamcorper a lacus. Ut faucibus pulvinar elementum integer.',
            1, 2),
            ('5', 'How do I get into the room guarded by 2 gargoyles at level 10?',
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Quam id leo in vitae. Nec feugiat in fermentum posuere urna nec tincidunt
            praesent semper. Proin nibh nisl condimentum id. Tempus quam pellentesque 
            nec nam aliquam sem et. Sociis natoque penatibus et magnis. A condimentum vitae sapien pellentesque habitant
            morbi tristique senectus. Rhoncus urna neque viverra justo nec ultrices. Metus dictum at tempor commodo 
            ullamcorper a lacus. Ut faucibus pulvinar elementum integer.',
            1, 2);";
            $db->query($insert);
    
        $insert = "
            INSERT INTO savedPosts (postID, uID) VALUES
            (1,2), (3,2), (4,2), (5,4), (3,1);";
            $db->query($insert);
    
        $insert = "
            INSERT INTO comment (postID, uID, cContent, cLikes, cStatusID) VALUES
            (1, 5,  'noticed a glitch on lv 5 but just added this code to fix',0,3),
            (4, 1,  'You need to find the magicians desk in lv 4 by going through a fake wall at the top right back corner of the level',2,1),
            (3, 4,  'would love to see some time based enemies',1,1),
            (3, 2,  'see some enemies that move in a set path you have to get past would be cool',2,1),
            (5, 3, 'You need to grab a torch and place it in front of the gargoyles then you can enter', 3, 1);";
            $db->query($insert);
            
    }elseif($dataForSite[$activeSite]['db_name']=='learn_hindi'){   
        /*Insert Data into userType*/
        $insert = "INSERT INTO usertype (uType) VALUES ('user'), ('admin');";
        $db->query($insert);
        
        /*Insert Data into status*/
        $insert = "INSERT INTO status (statusType) VALUES 
        ('Public'), 
        ('Draft'),
        ('Reported'),
        ('True Report'),
        ('False Report'),
        ('Restricted Access'),
        ('View Only'),
        ('Blocked');";
        $db->query($insert);
        
         //user hashed passwords
         $hashedPassword_ben ='$2y$10$uviArtFCuMEaSBPc83/uNeqxHN5iwC7spH.d5k/MUJ.nxSezLhe.S' ;
         $hashedPassword_sam ='$2y$10$ekdw0n25JvZ.hfyFls0iZO.jeIwKlSZgOd1ETUwySy7NMKpEAmK1.' ;
         $hashedPassword_alex ='$2y$10$I/41fGNDkurygrB3YpjkEOtlYi467wrXMky1spwWv6cK83zbKez0m' ;
         $hashedPassword_chloe ='$2y$10$FpQzElzDPvq5monFfAc36OW/3x48Op7gLvNSlb0ohs4sTjD6Pv4qS' ;
         $hashedPassword_damian ='$2y$10$V9sl0bfgTHDNjpI/ItYkz.BBJ6rSEKKg16KyB.f3FkvWiwV6uuvT6' ; 

        /*Insert Data into User*/
        $insert = "INSERT INTO user (uTypeID, uName, uPassword, uEmail, uStatusID) VALUES 
        (1,'Ben Ferguson', '$hashedPassword_ben', 'benferg@gmail.com',1),
        (1,'Samantha Adam', '$hashedPassword_sam', 'sAdams@gmail.com',1),
        (2,'Alex Cross', '$hashedPassword_alex', 'alexcross@gmail.com',1),
        (1,'Chloe Evans', '$hashedPassword_chloe', 'chloe.evans@gmail.com',1),
        (1,'Damian Skywalker', '$hashedPassword_damian', 'damien.s@gmail.com',3);";
        $db->query($insert);
        
         /*Insert Data into Post*/
         $insert = "INSERT INTO post (uID, postTitle, postContent, pStatusID, pLikes) VALUES
        ('1', 'Help with pronoucation of different greetings',
        'This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. ',
        1, 1),
        ('4', 'Anyone free in Auckland area to practice having conversation in Hindi?',
        'This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. ',
        1, 3),
        ('1', 'What are conjoins in Hindi?',
        'This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. ',
        1, 0),
        ('2', 'Help with guessing the different gender of words',
        'This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. ',
        1, 2),
        ('5', 'Any tips to better understand sentance structure order when speaking Hindi?',
        'This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. This is some text repeated over and over for post content. ',
        1, 5);";
        $db->query($insert);
        
        /*Insert Data into Post*/
        $insert = "INSERT INTO comment (postID, uID, cContent, cLikes, cStatusID) VALUES
        (2, 1,  'Yeah i am avaliable in the weekend. Did you have a place and time you wanted to meet at?',1,1),
        (2, 2,  'i would be keen to join if the time is before 12 on the weekends',0,1),
        (4, 4,  'This is some of the collected examples of gender in hindi I have found if it helps https://blogs.transparent.com/hindi/grammatical-gender-non-living-things/. Its tricky to get the hang of, I am still working on it myself.',3,1),
        (4, 5,  'video explaining gender which may help. https://www.youtube.com/watch?v=4ttcOo8rK4U',0,3),
        (5, 3, 'I remember having a lot of trouble with this, but found that this video really helped. https://www.youtube.com/watch?v=Tt4ALGhEm8E', 1, 1)
        ;";
        $db->query($insert);
        
        /*Insert Data into savedPosts*/
        $insert = "INSERT INTO savedPosts (postID, uID) VALUES
        (2,1), (2,2), (3,2), (5,2), (5,4);";
        $db->query($insert);
        
        /*Insert Data into reports = reporting comment*/
        /*$insert = "INSERT INTO reports (uID, postID, cID) VALUES 
        (2,NULL,4), (1,NULL,4), (4,4,NULL);";
        $db->query($insert);*/
    } 
    
    }
?>
<div class="post">
<div class="postContent">
<h2>
    <?php echo $row["postTitle"]; ?>
</h2>
<div class="userDisplay">
<?php if($row["uProfileImage"]!==NULL){
    $userProfileImage = $row["uProfileImage"];
    $imgPath = $dataForSite[$activeSite]['images_path'];
    $totalImagePath = $imgPath.$userProfileImage;

    ?>
    <div class='profileIcon'>
        <img src="<?php echo $totalImagePath; ?>" height="40px" width="40px" background-color="gray">
    </div>
<?php
}else{
    echo "<div class='profileIcon'>";
    include '..\images\svg\face-24px.svg';
    echo "</div>";
}
?>
        <h4>
         <!--postTitle-->   
        
        <?php echo $row["uName"]; ?>
    </h4>
    <p class="datePosted"><?php echo $row["pDatetime"]; ?></p>
        <!--<img src="" height="40px" width="40px" background-color="gray">-->
        <?php
        if( isset($_SESSION['user_ID'])  && $_SESSION['user_ID']==$row["uID"]){
            //if($row["uID"]==1){ 
           include '..\templates\userPostOptions.php';
        }else{?>
            <?php include "..\images\svg\outlined_flag-24px.svg" ?>
       <?php
     }
      ?>
    </div>
    <p>
        <!--postContent-->
        <?php echo $row["postContent"]; ?>
    </p>
    <?php if($row["pLikes"]>0){?>
    <div class="likeDisplay" onclick="alert('You have liked this post')">
        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
            <path d="M0 0h24v24H0V0z" fill="none" />
            <path
                d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" />
        </svg>
        <span class="like">
           <!-- 3 पसंद-->
            <?php echo  $row["pLikes"]." ".$dataForSite[$activeSite.'-post']['like']; ?>
        </span>
    </div>
    <?php
    }
    ?>
    <div id="commentDisplay_<?php echo $row['postID']; ?>" style="display:none;" class="commentDisplay">
        
        <?php include '../templates/commentDisplay.php'; ?>
    </div>
    <?php if( $count['commentTotal']>=1){?>
    <a id="viewAllComments_<?php echo $row['postID']; ?>" class="viewAllComments" href="#" onclick="viewComments(<?php echo $row['postID']; ?>)">
    <?php echo $count['commentTotal']." ". $dataForSite[$activeSite.'-post']['comment'];?>
    <?php
    }
    ?>
</a>
    <div class="postButtons">
        <button id="likeBtn_<?php echo $row['postID']; ?>" class="likeBtn btn" onclick="likeBtnToggle(<?php echo $row['postID']; ?>)">
            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
                <path d="M0 0h24v24H0V0z" fill="none" />
                <path
                    d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" />
            </svg>
            <?php echo $dataForSite[$activeSite.'-post']['like']; ?>
        </button>
        <button id="saveBtn_<?php echo $row['postID']; ?>" class="saveBtn btn" onclick="saveBtnToggle(<?php echo $row['postID']; ?>)">
            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
                <path d="M0 0h24v24H0z" fill="none" />
                <path d="M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z" /></svg>
                <?php echo $dataForSite[$activeSite.'-post']['saved']; ?>
        </button>
        <button id="commentBtn_<?php echo $row['postID']; ?>" class="commentBtn btn" onclick="commentBtnToggle(<?php echo $row['postID']; ?>)">
            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
            <?php echo $dataForSite[$activeSite.'-post']['comment']; ?>
        </button>
    </div>
    <!--invisible div controls for connecting js to php-->
    <div>
    <!--<input type="submit" id="deletePost-btn" name="deletePost" value="delete">
    <input type="submit" id="editPost-btn" name="editPost" value="edit">
    <input type="text" name="postID" value="<?php echo $row['postID']; ?>">
    <input type="image" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.aXSIQMH3Xi6Rr2OIRRXDEgHaHa%26pid%3DApi&f=1" alt="Submit" style="float:right" width="48" height="48">-->
    </div>
</div>
</div>
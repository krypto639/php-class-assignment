<div id="userPostCreate">
<?php
    $userLoggedIn=$_SESSION['user_ID'];
    $sql_profile = "SELECT * FROM user WHERE uID=$userLoggedIn";
    $uProfile_retrieve = $db->query($sql_profile);
    $uDetails=$uProfile_retrieve->fetch();
    //while($uDetails){
    $db_uProfileImage = $uDetails['uProfileImage'];
    echo "<script>console.log($db_uProfileImage);</script>";
    
if($db_uProfileImage!==NULL){
    $userProfileImage = $uDetails["uProfileImage"];
    $imgPath = $dataForSite[$activeSite]['images_path'];
    $totalImagePath = $imgPath.$userProfileImage;

    ?>
    <div class='profileIcon'>
        <img src="<?php echo $totalImagePath; ?>" height="40px" width="40px" background-color="gray">
    </div>
<?php
}else{
    echo "<div class='profileIcon'>";
    include '..\images\svg\face-24px.svg';
    echo "</div>";
}
?>
<form action="../pages/postPg.php" method="POST" name="postCreate-form">
                <input class="postTitleInput" name="postTitle" type="text" placeholder="
                <?php echo $dataForSite[$activeSite.'-post']['title_placeholder']; ?>
                ">
                <textarea rows="5" name="postText" placeholder="
                <?php echo $dataForSite[$activeSite.'-post']['content_placeholder']; ?>
                "></textarea>
                <input class="postCreateBtn submitBtn btn" name="createPost-btn" type="submit" value="
                <?php echo $dataForSite[$activeSite.'-post']['create_post']; ?>
                ">
                    <!--onclick="alert('You have submitted a new post')"-->
            </form>
        </div>
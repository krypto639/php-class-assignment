<?php
if(!isset($activePage)){
    $activePage='';
}
?>
<div id="menuBar">
        <div class="siteName">
            <a 
            <?php if($activePage=='Home'){echo "class='activePage'";} ?>
             href="homePg.php"><?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['site_name'] ); ?></a>
        </div>
        <div class="siteNavPages">
            <a href="#" onclick="alert('This is the about page link')">
            <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['about_link'] ); ?>
        </a>
            <a href="#" onclick="alert('This is the lessons page link')">
            <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['content_link'] ); ?>
        </a>
            <a href="#" onclick="alert('This is the leaderboard page link')">
            <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['leaderboard_link'] ); ?>
        </a>
            <a
            <?php if($activePage=='Post'){echo "class='activePage'";} ?>
            href="postPg.php">
            <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['post_link'] ); ?> 
            </a>

            
            <?php 
            if( isset($_SESSION['user_ID']) ){
                ?>
                <a href='../pages/account.php'
                <?php if($activePage=='Account'){echo "class='activePage'";} ?>
                >
                    <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['account'] ); ?>
                </a>
                <a href='../operation/logout.php'>
                    <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['log_out'] ); ?>
                </a>
                <?php
            }elseif( !isset($_SESSION['user_ID']) ){
                ?>
                <a
                    <?php if($activePage=='LogIn'){ echo "class='activePage'"; }?>
                    href='loginPg.php'>
                    <?php echo htmlspecialchars( $dataForSite[$activeSite.'-navContent']['log_in'] );?>
                </a>
            <?php } ?>
            <!--<a class="searchIcon" href="#" onclick="alert('This is the search feature. Coming Soon')">
                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
            </a>
            <a href="#"  onclick="alert('This is your account which offers access to account, saves and reports if logged in as a admin')">
                <img class="menuImg menu_profileImg" src="userProfileIcon.jpg" alt="user profile icon">
            </a>-->
        </div>
    </div>
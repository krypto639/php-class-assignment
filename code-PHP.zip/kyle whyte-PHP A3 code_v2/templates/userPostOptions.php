<div class="userPostOptions">
            <a class="edit" href="../pages/editPost.php?postID=<?php echo $row['postID'];?>">
                <?php include "../images/svg/create-black-18dp.svg"; ?>
            </a>
            <a class="delete" href="../operation/delete.php?postID=<?php echo $row['postID'];?>">
            <?php include "..\images\svg\delete-black-18dp.svg"; ?>
        </a>
        </div>
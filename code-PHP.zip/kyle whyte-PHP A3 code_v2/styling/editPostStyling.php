<style>
.flexBody{
    display:flex;
    justify-content:center;
    flex-direction:column;
    height:97vh;
    width:100vw;

}

#editPostContent{
    /*border: 3px solid green;*/
    background-color:var(--secondary);
    border-radius:18px;
    padding:15px;
    display:flex;
    align-self:center;
    position:relative;
    top:-100px;
    width:98vw;
    max-width:700px;
   
}

#editPostContent form{
    display:flex;
    flex-direction:column;
    justify-content:center;
}

#editPostContent textarea{
    margin-bottom:20px;
    width:95vw;
    max-width:680px;
    text-align:left;
    resize:none;
}

.new-postTitleInput{
    font-size:2.0em;
}
#updatePost-btn{
background-color:var(--inactive_color);
color:var(--secondary);
font-size:1.1em;
margin:20px auto 0;
border-radius:25px;
padding:15px;
width:150px;
}

#updatePost-btn:hover{
    background-color:var(--primary);   
}
</style>
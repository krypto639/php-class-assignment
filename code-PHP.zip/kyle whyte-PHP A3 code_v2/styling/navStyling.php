<style>
#menuBar{
    background-color:var(--background_color2);
    display:flex;
    flex-direction:row;
    justify-content:space-between;
    align-content:center;
    top:0;
    left:0;
    width:100%;
    height:50px;
    padding-bottom:7px;
    margin-bottom:70px;
    position:absolute;
}


#menuBar .activePage{
    color:var(--primary);
   }

.siteName a{
    text-decoration:none;
    font-size:30px;
    margin:10px;
    float:left;
    color:var(--secondary);
}
.siteNavPages{
    float:right;
    margin-right: 20px;
    margin-top:20px;
    /*background-color: crimson;*/
    /*width: 70%;*/
}

.siteNavPages a{
    margin-left: 20px;
    font-size:20px;
    text-decoration: none;
    color:var(--secondary);
    /*background-color:green;*/
}

.siteNavPages a:hover, .siteName a:hover{
    /*text-decoration: underline;*/
    color:var(--primary);
}


.menu_profileImg{
    border-radius:50px;
}
</style>
<style>
#logInPage{
    display:flex;
    flex-direction:center;
    justify-content:center;
    align-content: center;
    min-height:97vh;
}

    #logInBox{
    background-color:var(--secondary);
    border-radius:15px;
     display:flex;
     flex-direction:column;
     justify-content:center;
     width:50vw;
     height:60vh;
     max-width:800px;
     max-height:500px;
     padding:20px;
     position:relative;
     top:-70px;
    }

    #logInBox h1{
        text-align:center;
        color:var(--primary);
        font-size:2.6em;
        position:relative;
        /*top:-10px;*/
    }

    #logInForm, #RegisterForm{
        /*background-color:aqua;*/
        width:100%;
        max-width:500px;
        margin:0 auto;
        /*display:flex;
        flex-direction:column;
        justify-content:center;
        width:100%;*/
    }
    
    #logInForm label, #RegisterForm label{
        margin-right:25px;
        font-size:1.1em;
    }

    #logInForm input, #RegisterForm input{
    margin:15px 0;
}


input::placeholder {
  text-align:left;
  margin-left:0;
  padding-left:0;
}

.error{
    color:red;
    font-style:bold;
}

.form-submit{
    margin:10px auto 20px;
    border-radius:15px;
    background-color:var(--inactive_color);
    color:var(--secondary);
    padding:7px;
    font-size:1.2em;
}

.form-submit:hover{
    background-color:var(--primary);
}

</style>
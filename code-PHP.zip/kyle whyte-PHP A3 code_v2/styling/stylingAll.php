<style>
    :root {
    --primary:<?php echo $dataForSite[$activeSite.'-styling']['primary_color']; ?>;
    --secondary:<?php echo $dataForSite[$activeSite.'-styling']['secondary_color']; ?>;
    --background:<?php echo $dataForSite[$activeSite.'-styling']['background_color']; ?>;
    --inactive_color:<?php echo $dataForSite[$activeSite.'-styling']['inactive_color']; ?>;
    --background_color2:<?php echo $dataForSite[$activeSite.'-styling']['background_color2']; ?>;
    --displayFont:<?php echo $dataForSite[$activeSite.'-styling']['display_font']; ?>;
    --tester:#F90E16;
    --tester2:#FBF8F1;
    --black:<?php echo $dataForSite[$activeSite.'-styling']['red']; ?>;
    /*--black:#2A2727;*/

  }

body{
    display: flex;
    justify-content: center;
    align-content: center;
    flex-direction: column;
    flex-wrap: wrap;
    overflow-x:hidden;
    background-color:var(--background);
}

h1, h2, h4{
  font-family:var(--displayFont);
}
</style>
<?php
include 'navStyling.php';
include 'homeStyling.php';
include 'loginStyling.php';
include 'postStyling.php';
include 'editPostStyling.php';
include 'accountPgStyling.php';
?>
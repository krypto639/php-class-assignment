<style>
#accountPg{
}
#accountPg .profileIcon, #account-uName{
    margin:0 auto;
}

#accountPg .profileIcon svg{
fill:var(--secondary);
width:100px;
height:100px;
}

#account-uName{
    color:var(--secondary);
    font-size:3em;
    margin-bottom:20px;
}

#accountStat-container{
    /*border:3px solid yellow;*/
    display:flex;
    flex-direction:row;
    justify-content:space-evenly;
    width:50vw;
    max-width:700px;
}

.stat-box{
    background-color:var(--secondary);
    width:30vw;
    max-width:240px;
    margin:0 15px;
    display:flex;
    justify-content:center;
    text-align:center;
    align-content:center;
}

.stat-box p{
color:var(--background_color2);
font-size:1.6em;
}

.stat-box h1{
color:var(--primary);
font-size:4em;
position:relative;
top:20px;
right:40px;
}
</style>
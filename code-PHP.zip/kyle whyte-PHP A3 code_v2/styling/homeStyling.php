<style>

  /*TOC:Homepage Styling*/
.backgroundImage{
    width:100%;
    height:100vh;
    left:0;
    right:0;
    display:flex;
    justify-content:center;
    align-content: center;
    vertical-align: middle;
    /*background-image: url("https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fuserscontent2.emaze.com%2Fimages%2Fada28be2-6e3e-44d0-8f89-40dfe4520f44%2F5293f12ae0a5e47ecfe9efa1b6e19d01.jpg&f=1&nofb=1");*/
    /*background-image: url("https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Forig10.deviantart.net%2Ff697%2Ff%2F2007%2F142%2F3%2F3%2Ftesey_and_minotaur_by_bloommer.jpg&f=1&nofb=1");*/
    /*background-image: url("https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2F4.bp.blogspot.com%2F-iJb1QEC91vo%2FVSw0u9zlxvI%2FAAAAAAAAFa8%2FRHJsguYJM3s%2Fs1600%2FMINOTAUR%252BTHESEUS%252BTHREAD.jpg&f=1&nofb=1");*/
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
}

.homepage_textDisplay{
    color:whitesmoke;
    text-shadow: 2px 2px #000;
    text-align:center;
}

.homepage_textDisplay h1{
font-size:60px;
}

.homepage_textDisplay h3{
    font-size:28px;
    }  
</style>
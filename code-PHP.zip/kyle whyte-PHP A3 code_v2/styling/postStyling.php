<style>
#changePostDisplay .activeFilter{
    color:var(--primary);
    text-decoration:underline;
}

.centerColumn{
    /*border:3px solid aqua;*/
    display:flex;
    flex-direction:row;
    justify-content:space-between;
    width:96vw;
    position:relative;
    top:-100px;
}

#allPostsDisplay{
    float:right;
    position:relative;
    left:35vw;
    /*border: 3px solid red;*/
    width:60vw;
}

#changePostDisplay{
    display:flex;
    flex-direction:column;
    background-color: var(--background_color2);
    border-radius:12px;
    position:fixed;
    width:50vw;
    max-width:300px;
    padding:30px 15px 10px ;
    height:200px;
}

#changePostDisplay a{
    color:var(--secondary);
    text-decoration:none;
    font-size:1.6em;

}

#changePostDisplay a:hover{
    color:var(--primary);

}

/*User Post Create */
#userPostCreate{
background-color:var(--secondary);
padding:15px;
display: flex;
flex-direction: row;
justify-content:space-between;
flex-wrap: wrap;
}

#userPostCreate img, #userPostCreate svg{
height:40px;
width:40px;
float:left;
}

#userPostCreate form{
/*border:3px solid aqua;*/
width:90%;
float:right;
}

#userPostCreate .postTitleInput{
width:100%;
font-size:1.3em;
margin-bottom:15px;
background-color:var(--inactive_color);
color:var(--secondary);
}

#userPostCreate form textarea{
    width:100%;
    resize:none;
    margin-bottom:15px;
    background-color:var(--inactive_color);
    color:var(--secondary);
    }

    #userPostCreate .postCreateBtn{
        float:right;
        font-size:1.1em;
        padding:5px 0;
        background-color:var(--background_color2);
        color:var(--secondary);
        }

        #userPostCreate .postCreateBtn:hover{
        background-color:var(--primary);
        color:var(--secondary);
        }

/*TOC: Title Post display*/
.titleDisplayOnly-post{
    background-color:var(--secondary);
    padding:5px 15px 15px;
    border-radius:12px;
}

.titleDisplayOnly-post h2{
   color:var(--primary);
   font-size:1.6em;
}

.titleDisplayOnly-post a{
   color:var(--inactive_color);
   text-decoration:none;
   position:relative;
   top:-10px;
   font-size:1.2em;
}

.titleDisplayOnly-post a:hover{
   color:var(--primary);
text-decoration:underline;
}


/*TOC: Post display*/
.post{
    border: 3px solid var(--inactive_color);
    background-color:var(--secondary);
    border-radius: 10px;
    margin-bottom:10px;
    padding:0 15px 15px;
    /*background-color: var(--color6);*/
    object-fit:cover;
    height:auto;
}

.postContent h2{
    color:var(--primary);
}

.userDisplay{
    /*background-color:red;*/
}

.userDisplay svg{
    float:right;
    width:40px;
    height:40px;
    position:relative;
    top:-60px;
    /*background-color:white;*/
}

.userDisplay img{
    border-radius:50%;
    float:left;
}

.profileIcon svg{
    float:left;
    width:40px;
    height:40px;
    position:none;
    top:0;
}

.userDisplay h4{
    float:left;
    margin:5px 15px 0;
}

.datePosted{
    position:relative;
    top:-5px;
    left:20px;
    font-style:italic;
}

.post p{
    /*background-color: brown;*/
    float:right;
    width:92%;
    margin-left:8%;
    margin-top:-10px;
}
.likeDisplay{
    /*background-color: aquamarine;*/
    float:right;
    margin:5px 0 15px;
}

.likeDisplay svg{
    width:20px;
    height:20px;
    padding-right:5px;
}

.comment{
    width:100%;
    /*background-color:red;*/
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    margin-bottom:10px;
}

.comment .likeDisplay{
background-color: blanchedalmond;
width:100px;
margin-left:82%;
}

.viewAllComments{
    /*background-color:purple;*/
    text-decoration: none;
    text-align:right;
    float: right;
    width: 100%;
    margin:0px 0 20px;
}


.postButtons{
    /*background-color: orange;*/
    align-content: center;
    width:100%;
    display:flex;
    flex-direction: row;
}

.btn{
    width:27%;
    margin:0 3%;
    border-radius:5px;
    /*background-color:seagreen;*/
    text-align:center;
    vertical-align: center;
    justify-content: center;
    float:left;

}

.activeBtn{
    /*background-color:royalblue;*/
    background-color:var(--primary); 
}


.commentInputBox{
    margin:10px 0;
    /*background-color: salmon;*/
    border: 3px solid var(--black);
    border-radius:5px;
    width:100%;
    height:auto;
    float:left;  
}

.commentInputBox form{
padding:10px;
/*background-color:skyblue;*/
}
.commentInputBox textarea{
    width:100%;
    resize:none;
}

/*.commentInputBox */.submitBtn{
    float:right;
    margin:5px 0 10px;
    border-radius:5px;
    /*background-color:goldenrod;*/
    height:30px;
}
.btn:hover{
    background-color:var(--primary);
    color:white;
}


#pageNav{
    /*background-color:red;*/
    display:flex;
    justify-content: center;
    width:50%;
    margin:20px 25% 40px;
}

#pageNav svg{
    width:50px;
    height:50px;
}


#pageNav svg:hover{
    fill: red;
}

#pageNav a{
    font-size:24px;
    margin: auto 10px;
    text-decoration: none;
}

#pageNav a:hover{
    color:red;
}

#pageNav .active{
    text-decoration: underline;
    font-weight: bold;
}

/*user options */
.userPostOptions svg{
    height:30px;
    width:30px;
    fill:var(--inactive_color);
    padding-left:3px;
}

.userPostOptions svg:hover{
    fill:var(--primary);
}

/* POST view box */
#postViewbox{
    width:80%;
    max-width:700px;
}

#postViewbox .post{
    position:relative;
    top:-80px;
}
</style>